###Welcome to use MarkDown

聊天室接口规范 V1.0
请求命令类型:
    以下命令编码均为小写。
public static string ToOnline = "TOONLINE";  ///给在线所有人发言(广播)
public static string ToAll = "TOALL";///给当前整个聊天室发言(公聊)
public static string ToPersonal = "TOPERSONAL";///给别人发私信(私聊)
public static string ToPersonalShow = "TOPERSONALSHOW";///发私信显示公屏顶部(私聊)
public static string PutProblem = "PUTPROBLEM";///提问
public static string Answer = "ANSWER"; /// 回答问题
public static string NoSpeak = "NOSPEAK";/// 禁言
public static string CloseRoom = "CLOSEROOM";/// 关闭聊天室
public static string GetChatHistory = "GETCHATHISTORY";/// 获取聊天历史
public static string GetPrivmsg = "GETPRIVMSG";/// 获取私信
public static string Heart = "HEART"; /// 心跳包(客户端两分钟自动调用一次)

客户端请求示例：
{
    "act": "toall",   //命令
    "room": 2344,  //房间号
    "touser": "76723",  //userid
    "from": {     //个人信息(需将from整体编码,内部可以扩展)
        "userid": "1213",
        "name": "李四",
        "pic": "http://sjdkfj.skdjf.png"
    },
    "content": {  //信息内容(需将content整体编码,内部可以扩展)
        "msg": "消息内容---天气很好。",
        "question": "天气怎么样？"
    }
}

服务器响应示例:
{
    "code": 5,  //响应编码
    "timestamp": "20160526140115", //响应时间(时间戳)
	"msg":"提示内容",   //提示内容
    "data": [
        {
            "content": {  //信息内容(需解码)
                "msg": "消息内容"
            },
            "from": {  //发送人个人信息(需解码)
                "userid": "1213",
                "name": "李四",
                "pic": "http: //sjdkfj.skdjf.png"
            },
            "to": {  //接收人个人信息(需解码)
                "userid": "1213",
                "name": "张三",
                "pic": "http: //sjdkfsdfasdff.png"
            },
            "timestamp": "20160526140115"//消息时间(时间戳)
        }
    ]
}


响应消息类型:
 	以下编码均以数字为准.
    public static int Warning = -1; ///警告
public static int TryLogin = -2; /// 重新登录
public static int CloseRoom = -3;  /// 关闭房间
    public static int BroadcastData = 5; /// 广播消息
    public static int BroadcastHistoryData = 6; ///历史广播消息
    public static int PrivateLetter = 7; /// 私信
    public static int PrivateLetterShow = 8; /// 私信(公聊区着重显示)
    public static int SetPrivmsg = 9; /// 历史私信
    public static int SetPutProblem = 10; /// 提问消息
    public static int SetAnswer = 11; /// 老师回复
    public static int SetAdmin = 12; /// 管理员发送消息


API接口处:
客户端请求Web接口示例：
http://zjzx.test.com/zh-CN/Chat/ GetUserConfig?room=001    // room为房间号
服务端返回示例：
	{
    "status": 1, //状态码  0----失败，1---成功
    "msg": "asdf", //提示消息(当失败时有内容)
    "result": {
        "ukey": "asidf;ajdkf;jakdsjfksajf;lksa",  //用户Ukey
        "userid": "t343423", //用户ID
        "name": "张三", //姓名
		“pic”:”111.jpg”,//头像
	    “websocketurl”:”192.168.1.1”// WebSocket地址
          }
}


